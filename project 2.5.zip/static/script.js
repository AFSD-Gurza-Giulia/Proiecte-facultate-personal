let currentBookId = null;
let bookModal = null;

document.addEventListener('DOMContentLoaded', function() {
    bookModal = new bootstrap.Modal(document.getElementById('bookModal'));
    loadBooks();
});

function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alertContainer');
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    alertContainer.appendChild(alert);

    setTimeout(() => {
        if (alert.parentNode) {
            alert.remove();
        }
    }, 3000);
}

async function loadBooks() {
    try {
        const response = await fetch('/items');
        if (response.ok) {
            const books = await response.json();
            displayBooks(books);
        } else {
            showAlert('Error loading books', 'danger');
        }
    } catch (error) {
        showAlert('Error connecting to server', 'danger');
    }
}

function displayBooks(books) {
    const tbody = document.getElementById('booksTable');
    tbody.innerHTML = '';

    books.forEach(book => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${book.id}</td>
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.year || ''}</td>
            <td>${book.genre || ''}</td>
            <td>
                <button class="btn btn-sm btn-warning me-1" onclick="editBook(${book.id})">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deleteBook(${book.id})">Delete</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}


function openAddModal() {
    currentBookId = null;
    document.getElementById('modalTitle').textContent = 'Add Book';
    document.getElementById('bookForm').reset();
}


async function editBook(id) {
    try {
        const response = await fetch(`/items/${id}`);
        if (response.ok) {
            const book = await response.json();
            currentBookId = id;
            document.getElementById('modalTitle').textContent = 'Edit Book';
            document.getElementById('title').value = book.title;
            document.getElementById('author').value = book.author;
            document.getElementById('year').value = book.year || '';
            document.getElementById('genre').value = book.genre || '';
            bookModal.show();
        } else {
            showAlert('Book not found', 'danger');
        }
    } catch (error) {
        showAlert('Error loading book data', 'danger');
    }
}


async function saveBook() {
    const title = document.getElementById('title').value.trim();
    const author = document.getElementById('author').value.trim();
    const year = document.getElementById('year').value.trim();
    const genre = document.getElementById('genre').value.trim();

    if (!title || !author) {
        showAlert('Title and Author are required', 'warning');
        return;
    }

    const bookData = { title, author, year, genre };

    try {
        let response;
        if (currentBookId) {

            response = await fetch(`/items/${currentBookId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bookData)
            });
        } else {

            response = await fetch('/items', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bookData)
            });
        }

        if (response.ok) {
            const action = currentBookId ? 'updated' : 'added';
            showAlert(`Book ${action} successfully!`, 'success');
            bookModal.hide();
            loadBooks();
        } else {
            const error = await response.json();
            showAlert(error.error || 'Error saving book', 'danger');
        }
    } catch (error) {
        showAlert('Error connecting to server', 'danger');
    }
}

// Șterge o carte
async function deleteBook(id) {
    if (!confirm('Are you sure you want to delete this book?')) {
        return;
    }

    try {
        const response = await fetch(`/items/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            const result = await response.json();
            showAlert(result.message, 'success');
            loadBooks();
        } else {
            const error = await response.json();
            showAlert(error.error || 'Error deleting book', 'danger');
        }
    } catch (error) {
        showAlert('Error connecting to server', 'danger');
    }
}